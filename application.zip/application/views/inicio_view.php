   <div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">
                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header"><?php echo $this->lang->line('mensajes_titulo_menus'); ?></li>
                        <?php echo $menu; ?>
                    </ul>
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div>
    <ul class="breadcrumb">
        <li>
            <a href="#">Inicio</a>
        </li>
    </ul>
</div>
<div class="ch-container">
    <div class="row">
        <div class="box col-md-12">
            <div class="box-inner">
                <div class="box-header well" data-original-title="">
                    <h2><i class="glyphicon glyphicon-user"></i> Datos Cargados</h2>
                        <div class="box-icon">
                            <a href="#" class="btn btn-setting btn-round btn-default"><i class="glyphicon glyphicon-cog"></i></a>
                            <a href="#" class="btn btn-minimize btn-round btn-default"><i class="glyphicon glyphicon-chevron-up"></i></a>
                            <a href="#" class="btn btn-close btn-round btn-default"><i class="glyphicon glyphicon-remove"></i></a>
                        </div>
                </div>
            <div class="box-content">
                <div class="row" style="text-align: right;">
                        
                            <div class="col-md-12">
                                <a class="btn btn-success" href="cargaactividades"><i class="glyphicon glyphicon-plus-sign icon-white"></i> Cargar Horas</a>
                            </div>
                            <br>
                    </div>
                
                <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
                    
                        <div class="table-wrapper">
                            <div class="scrollable">
                                <table class="table table-striped table-bordered bootstrap-datatable datatable responsive dataTable" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
                                    <thead>
                                        <tr role="row">
                                        <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Username: activate to sort column descending" style="width: 196px;">Inicio</th>
                                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Role: activate to sort column ascending" style="width: 88px;">Fin</th>
                                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Role: activate to sort column ascending" style="width: 88px;">Alumno</th>
                                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 88px;">Actividad</th>
                                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Date registered: activate to sort column ascending" style="width: 165px;">Observaciones</th>
                                        <th class="sorting" role="columnheader" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Actions: activate to sort column ascending" style="width: 286px;">Acciones</th>
                                        </tr>
                                    </thead>
            <!-- impresión de la tabla -->
            
            <?php 
                    if (!isset($actividades)) {
                        echo "<h2>Lo siento, no se puede mostrar su consulta</h2>";
                        exit();
                    }else{
                        echo '<tbody role="alert" aria-live="polite" aria-relevant="all">';
                        $i = 1;
                        

                            foreach ($actividades as $actividad) {
                            
                                if ($i%2==0) {
                                    echo '<tr class="even">';
                                }else{
                                    echo '<tr class="odd">';
                                }

                                
                                echo '<td class=" sorting_1">'.$actividad->fecha_inicio.'</td>';
                                echo '<td class="center ">'.$actividad->fecha_fin.'</td>';
                                echo '<td class="center ">'.$actividad->id_alumnos.'</td>';
                                echo '<td class="center ">'.$actividad->id_tipo_actividades.'</td>';
                                echo '<td class="center ">'.$actividad->observaciones.'</td>';
                                echo '<td class="center ">
                                        <a class="btn btn-success" href="#">
                                        <i class="glyphicon glyphicon-zoom-in icon-white"></i>
                                        Info
                                        </a>
                                        <a class="btn btn-info" href="#">
                                        <i class="glyphicon glyphicon-edit icon-white"></i>
                                        Editar
                                        </a>
                                        <a class="btn btn-danger" href="#">
                                        <i class="glyphicon glyphicon-trash icon-white"></i>
                                        Eliminar
                                        </a>
                                        </td>
                                        </tr>';
                            $i++;
                            }
                            
                        
                    }

                     ?>

                            </tbody>
                            </table>
                            </div>